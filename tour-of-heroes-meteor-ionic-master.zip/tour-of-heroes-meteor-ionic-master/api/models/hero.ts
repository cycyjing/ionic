export interface Hero {
  _id?: string;
  name?: string;
}
